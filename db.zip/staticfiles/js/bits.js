let bits = [
  {
  numb: 1,
  question: "Animal without red blood cells?",
  answer: "Earthworm",
  options: [
         "Frog",
         "Earthworm",
         "Snake",
         "Peacock"
  ]
},
  {
  numb: 2,
  question: "The human heart is?",
  answer: "Myogenic heart",
  options: [
   "Neurogenic heart",
   "Myogenic heart",
   "Pulsating heart",
   "Ampullary heart"
  ]
},
  {
  numb: 3,
  question: "The process where characteristics are transmitted from parent to offsprings is called ?",
  answer: "Heredity",
  options: [
   "Variation",
    "Heredity",
    "Gene",
    "Allele"
  ]
},
  {
  numb: 4,
  question: "The energy released by 1 gram of glucose is?",
  answer: "4 kcal",
  options: [
   "6 kcal",
   "4 kcal",
   "5 kcal",
   "3kcal"
  ]
},
  {
  numb: 5,
  question: "Chambered heart occurs in?",
  answer: "Cockroach",
  options: [
    "Leech",
    "Earthworm",
    "Snail",
    "Cockroach"
  ]
},
  {
  numb: 6,
  question: "The corner of the cells of collenchyma tissue in plant are thickened due to deposition of _____?",
  answer: "Cellulose and pectin",
  options: [
    "Lignin and suberin",
     "Suberin and cutin",
     "Cellulose and pectin",
    "Chitin and lignin"
  ]
},
  {
  numb: 7,
  question: "From the following pairs, find the one which is correctly matched?",
  answer: "Malaria- Chloroquine",
  options: [
    "Scurvy- Thiamine",
    "Tuberculosis- ATS", 
    "Tetanus- BCG",
    "Malaria- Chloroquine" 
  ]
},
  {
  numb: 8,
  question: "The phenomenon of summer sleep by animals is called?",
  answer: "aestivation",
  options: [
    "hibernation",
    "aestivation",
    "laziness",
    "lethargy"
  ]
},
  {
  numb: 9,
  question: "Bone deformities occur due to the excess intake of?",
  answer: "Fluorine",
  options: [
    "Phosphorus",
    "Potassium",
    "Fatty acid",
    "Fluorine"
  ]
},
{
  numb: 10,
  question: "Hardest Part of the Human Body??",
  answer: "Tooth Enamel",
  options: [
   "Tooth Enamel",
   "Femur",
   "Temporal bone of skull",
   "Knee bone"
  ]
},
];